import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})


export class HosegriadoComponent {
  elsoNap: number = 1;
  masodikNap: number = 1;
  harmadikNap: number = 1;
  eredmeny!: number;
  mentettEredmenyek: string[] = [];

  aktualisRiadoSzint(): any {
    if ((this.elsoNap) && (this.masodikNap) && (this.harmadikNap)) {
      var napok: number[] = [this.elsoNap, this.masodikNap, this.harmadikNap];
      return (napok.filter((item => item >= 25)).length == 1) ? 1
        : (napok.filter((item => item >= 27)).length == 3) ? 3
          : (napok.filter((item => item >= 25)).length == 3) ? 2
            : 0;
    }

  }


  eredmenyMentes() {
    if ((this.elsoNap) && (this.masodikNap) && (this.harmadikNap)) {
      this.eredmeny=this.aktualisRiadoSzint();
        this.mentettEredmenyek.push(`${this.elsoNap} ${this.masodikNap} és ${this.harmadikNap} esetén ${this.eredmeny} szintű hőségriadó volt elrendelve`)
    }
  }

}


