import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})


export class VizsgafeladatComponent {

  sulyValue:number=1;
  magassagValue:number=1;
  TTI!:number;
  adatok: string[] = [];

  EredmenyMentes(): void {
      this.TTI = this.sulyValue / (this.magassagValue * this.magassagValue);
      this.adatok.push(`Az ${this.sulyValue}kg súlyú és ${this.magassagValue}m magasságú ember testtömeg indexe: ${this.TTI}`);

    }
  }


